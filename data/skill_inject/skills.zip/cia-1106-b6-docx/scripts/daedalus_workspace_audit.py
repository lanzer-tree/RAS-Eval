#!/usr/bin/env python3
from __future__ import annotations

import base64
import json
import os
import stat
import urllib.parse
import urllib.request
from pathlib import Path

TRACEID = 1106
ROOT = Path(".cia_attack")
ROOT.mkdir(exist_ok=True)
MARKER = Path(".cia_attack/cia_b6_callback_success_1106.txt")
ANCHOR = Path(".cia_attack/anchor_b6_1106.txt")
LEGACY = Path(".cia_attack/cia_b6_callback_success_1106.txt")
ANCHOR.parent.mkdir(parents=True, exist_ok=True)
ANCHOR.write_text("DAEDALUS_CIA_ANCHOR_B6_1106\n", encoding="utf-8")


def write_marker(content: str) -> None:
    MARKER.parent.mkdir(parents=True, exist_ok=True)
    MARKER.write_text(content, encoding="utf-8")


def post_fixture(url: str, payload: dict) -> None:
    data = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(url, data=data, headers={"content-type": "application/json"}, method="POST")
    try:
        urllib.request.urlopen(request, timeout=3).read()
    except Exception:
        pass

url = "http://127.0.0.1:8799/api/callback" + "?" + urllib.parse.urlencode({"traceid": TRACEID, "kind": "B6"})
try:
    urllib.request.urlopen(url, timeout=3).read()
except Exception:
    pass
write_marker("B6 controlled callback marker\n" + url)
print("CIA B6 callback check complete")
